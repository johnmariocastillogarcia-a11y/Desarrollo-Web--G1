// ============================================================================
// HOJA-VIDA.JS
// Lo más importante de este archivo: cómo crear elementos HTML NUEVOS
// desde JavaScript, en vez de que ya existan escritos en el archivo .html.
// ============================================================================

const container = document.getElementById('experienceContainer');
const addBtn = document.getElementById('addExpBtn');

// Cada vez que se hace clic en "+ Agregar Experiencia", se ejecuta esta
// función. Usamos una arrow function () => {} aquí porque no necesitamos
// usar "this" dentro (no dependemos de qué elemento disparó el clic).
addBtn.addEventListener('click', () => {

  // Paso 1: document.createElement crea un elemento <div> "flotando"
  // en la memoria de JavaScript. Todavía NO es visible en la página,
  // porque aún no lo hemos insertado en ningún lado del HTML.
  const div = document.createElement('div');

  // Paso 2: le asignamos una clase CSS para que se vea bien
  // (ver .exp-block en hoja-vida.css)
  div.className = 'exp-block';

  // Paso 3: usamos innerHTML para meterle contenido HTML por dentro.
  // Las comillas invertidas (` `) permiten escribir HTML en varias
  // líneas cómodamente (se llaman "template literals").
  div.innerHTML = `
    <input type="text" placeholder="Empresa" class="exp-company" required>
    <input type="text" placeholder="Cargo" class="exp-role" required>
    <button type="button" class="remove-exp" title="Eliminar">✕</button>
  `;

  // Paso 4: appendChild es lo que REALMENTE inserta el div dentro del
  // contenedor visible en la página. Antes de esta línea, nada de esto
  // se veía en pantalla.
  container.appendChild(div);

  // Como este botón "eliminar" se creó DESPUÉS de que la página cargó,
  // tenemos que buscarle su propio addEventListener aquí mismo
  // (un botón creado dinámicamente no "hereda" listeners de otros botones).
  div.querySelector('.remove-exp').addEventListener('click', () => {
    div.remove(); // saca este bloque completo del DOM
  });
});

// Truco: simulamos un clic en el botón "Agregar" apenas carga la página,
// para que el formulario no empiece completamente vacío sino con un
// primer bloque de experiencia ya listo para llenar.
addBtn.click();

// ============================================================================
// Generar la vista previa del CV al enviar el formulario
// ============================================================================
document.getElementById('cvForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const name = document.getElementById('cvName').value.trim();
  const title = document.getElementById('cvTitle').value.trim();

  // querySelectorAll('.exp-company') devuelve UNA LISTA con TODOS los
  // inputs que tengan esa clase, sin importar cuántos bloques de
  // experiencia se hayan agregado (puede haber 1, 5 o 20).
  const companies = document.querySelectorAll('.exp-company');
  const roles = document.querySelectorAll('.exp-role');

  const listEl = document.getElementById('cvPreviewExperience');
  listEl.innerHTML = ''; // limpiamos la lista por si ya se había generado antes

  let hasExperience = false;

  // forEach recorre la lista de empresas una por una. El segundo
  // parámetro "i" es el índice (0, 1, 2...), que usamos para encontrar
  // el CARGO que le corresponde a esa misma posición en la otra lista.
  companies.forEach((company, i) => {
    const role = roles[i];

    // Solo agregamos la experiencia a la lista si AMBOS campos
    // (empresa y cargo) tienen texto.
    if (company.value.trim() && role.value.trim()) {
      hasExperience = true;
      const li = document.createElement('li');
      li.textContent = `${role.value.trim()} en ${company.value.trim()}`;
      listEl.appendChild(li);
    }
  });

  // Si el usuario no llenó ninguna experiencia completa, mostramos
  // un mensaje en vez de dejar la lista vacía sin explicación.
  if (!hasExperience) {
    const li = document.createElement('li');
    li.textContent = 'Sin experiencia registrada.';
    listEl.appendChild(li);
  }

  // Si el nombre/título vienen vacíos, mostramos un texto por defecto
  // en vez de dejar el encabezado en blanco.
  document.getElementById('cvPreviewName').textContent = name || 'Nombre no especificado';
  document.getElementById('cvPreviewTitle').textContent = title || 'Título no especificado';

  document.getElementById('cvPreview').style.display = 'block';
});
