// ============================================================================
// LOGIN.JS
// Controla la validación del formulario de login y el reto del "ojo".
// ============================================================================

// getElementById busca en todo el HTML el elemento con ese id exacto.
// addEventListener('submit', ...) le dice: "cuando este formulario se
// intente ENVIAR (botón submit o tecla Enter), ejecuta esta función".
document.getElementById('loginForm').addEventListener('submit', function (e) {

  // e es el objeto "evento" que el navegador nos pasa automáticamente.
  // e.preventDefault() CANCELA el comportamiento por defecto del navegador,
  // que sería recargar la página (o navegar a la URL del atributo action).
  // Sin esta línea, perderíamos todo el estado de la página al enviar.
  e.preventDefault();

  // "Bandera" booleana: empezamos asumiendo que todo está bien.
  // Cada validación que falle la va a poner en false. Al final, solo si
  // sigue en true, dejamos pasar el login.
  let isValid = true;

  // Buscamos en el DOM los elementos que vamos a necesitar, y los
  // guardamos en constantes para no tener que buscarlos varias veces.
  const email = document.getElementById('loginEmail');
  const pass = document.getElementById('loginPass');
  const emailErr = document.getElementById('emailError');
  const passErr = document.getElementById('passError');

  // ---- Paso 1: limpiar estados de un intento anterior ----
  // Si el usuario ya había fallado antes, quitamos los bordes rojos
  // y los mensajes de error viejos, para empezar la validación "limpia".
  [email, pass].forEach(el => el.classList.remove('error'));
  emailErr.textContent = '';
  passErr.textContent = '';

  // ---- Paso 2: validar el correo con una expresión regular ----
  // Desglose del patrón /^[^\s@]+@[^\s@]+\.[^\s@]+$/ :
  //   ^              -> inicio del texto
  //   [^\s@]+        -> uno o más caracteres que NO sean espacio ni @
  //   @              -> un arroba literal
  //   [^\s@]+        -> el dominio (otra vez, sin espacios ni @)
  //   \.             -> un punto literal (el \ evita que signifique "cualquier carácter")
  //   [^\s@]+        -> la extensión (com, co, etc.)
  //   $              -> fin del texto
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // .trim() quita espacios en blanco al inicio/final (para que " a@a.com "
  // con espacios no engañe la validación). .test() devuelve true/false.
  if (!emailRegex.test(email.value.trim())) {
    email.classList.add('error');                      // pinta el borde rojo (ver global.css)
    emailErr.textContent = 'Ingrese un correo electrónico válido.';
    isValid = false;                                    // apagamos la bandera
  }

  // ---- Paso 3: validar longitud de la contraseña ----
  if (pass.value.length < 6) {
    pass.classList.add('error');
    passErr.textContent = 'La contraseña debe tener al menos 6 caracteres.';
    isValid = false;
  }

  // ---- Paso 4: si TODO pasó, cambiar de vista ----
  // Nótese que revisamos TODAS las validaciones antes de decidir, en vez
  // de cortar en la primera que falle. Así el usuario ve todos sus
  // errores de una sola vez, no uno por uno en cada intento.
  if (isValid) {
    // "this" dentro de esta función apunta al elemento que disparó el
    // evento, es decir, al propio <form id="loginForm">.
    this.style.display = 'none'; // ocultamos el formulario completo

    const welcomeCard = document.getElementById('loginWelcome');
    // Insertamos el correo ingresado dentro del <span id="userEmailDisplay">
    document.getElementById('userEmailDisplay').textContent = email.value;
    welcomeCard.style.display = 'block'; // mostramos la tarjeta de bienvenida
  }
});

// ============================================================================
// DESAFÍO INDIVIDUAL 1
// Botón con icono de "ojo" que alterna type="password" <-> type="text"
// para mostrar u ocultar la contraseña en texto plano.
// ============================================================================

const togglePass = document.getElementById('togglePass');
const loginPassInput = document.getElementById('loginPass');

togglePass.addEventListener('click', () => {
  // getAttribute('type') lee el valor ACTUAL del atributo type del input.
  // Si actualmente es "password", significa que está oculta.
  const isHidden = loginPassInput.getAttribute('type') === 'password';

  // Operador ternario: condición ? valorSiVerdadero : valorSiFalso
  // Si estaba oculta (isHidden = true) -> la mostramos como "text"
  // Si ya estaba visible (isHidden = false) -> la volvemos a ocultar
  loginPassInput.setAttribute('type', isHidden ? 'text' : 'password');

  // Cambiamos también el emoji del botón para dar pista visual del estado:
  // 🙈 = "ya la estás viendo, haz clic para tapar"
  // 👁  = "está oculta, haz clic para ver"
  togglePass.textContent = isHidden ? '🙈' : '👁';

  // Actualizamos también el texto accesible (aria-label) para que
  // los lectores de pantalla anuncien la acción correcta.
  togglePass.setAttribute(
    'aria-label',
    isHidden ? 'Ocultar contraseña' : 'Mostrar contraseña'
  );
});
