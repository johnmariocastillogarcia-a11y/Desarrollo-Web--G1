// ============================================================================
// REGISTRO.JS
// Diferencia clave respecto al login: aquí validamos EN TIEMPO REAL,
// mientras el usuario escribe, usando el evento 'input' en vez de
// esperar al 'submit'.
// ============================================================================

const nameInput = document.getElementById('fullname');

// El evento 'input' se dispara CADA VEZ que el valor del campo cambia,
// es decir, con cada letra que el usuario escribe o borra.
nameInput.addEventListener('input', function () {
  // "this" aquí es el propio <input id="fullname">, porque la función
  // fue declarada con "function" normal (no con arrow function =>,
  // que NO tiene su propio "this").
  if (this.value.trim().length >= 3) {
    this.classList.remove('invalid');
    this.classList.add('valid');          // pinta el borde de verde
    document.getElementById('nameErr').textContent = '';
  } else {
    this.classList.remove('valid');
    this.classList.add('invalid');        // pinta el borde de rojo
    document.getElementById('nameErr').textContent = 'Mínimo 3 caracteres.';
  }
});

// ---- Validación del correo, también en tiempo real ----
const regEmail = document.getElementById('regEmail');
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

regEmail.addEventListener('input', function () {
  const errEl = document.getElementById('regEmailErr');
  if (emailRegex.test(this.value.trim())) {
    this.classList.remove('invalid', 'error'); // classList.remove acepta varias clases a la vez
    this.classList.add('valid');
    errEl.textContent = '';
  } else {
    this.classList.remove('valid');
    this.classList.add('invalid');
    errEl.textContent = 'Correo electrónico no válido.';
  }
});

// ---- Confirmación de contraseñas cruzadas ----
const regPass = document.getElementById('regPass');
const regPassConfirm = document.getElementById('regPassConfirm');

// Sacamos esta lógica a una función NOMBRADA (en vez de escribirla
// dos veces) porque la necesitamos ejecutar cuando cambie CUALQUIERA
// de los dos campos de contraseña.
function checkPasswordsMatch() {
  const errEl = document.getElementById('regPassConfirmErr');

  // Si el campo de confirmación todavía está vacío, no mostramos
  // ningún error todavía (sería molesto marcarlo en rojo de una vez).
  if (regPassConfirm.value.length === 0) {
    errEl.textContent = '';
    regPassConfirm.classList.remove('valid', 'invalid');
    return; // corta la función aquí, no sigue ejecutando el resto
  }

  if (regPass.value === regPassConfirm.value && regPass.value.length >= 6) {
    regPassConfirm.classList.remove('invalid');
    regPassConfirm.classList.add('valid');
    errEl.textContent = '';
  } else {
    regPassConfirm.classList.remove('valid');
    regPassConfirm.classList.add('invalid');
    errEl.textContent = 'Las contraseñas no coinciden.';
  }
}

// Escuchamos 'input' en AMBOS campos de contraseña. Así, si el usuario
// modifica la primera contraseña después de haber escrito la confirmación,
// también se revalida automáticamente.
regPass.addEventListener('input', checkPasswordsMatch);
regPassConfirm.addEventListener('input', checkPasswordsMatch);

// ============================================================================
// Envío final del formulario (revalidamos TODO por seguridad, aunque ya
// se haya validado en tiempo real, por si el usuario nunca "tocó" un campo)
// ============================================================================
document.getElementById('regForm').addEventListener('submit', function (e) {
  e.preventDefault();
  let isValid = true;

  const name = document.getElementById('fullname');
  const email = document.getElementById('regEmail');
  const pass = document.getElementById('regPass');
  const passConfirm = document.getElementById('regPassConfirm');
  const terms = document.getElementById('terms');
  const termsErr = document.getElementById('termsErr');
  const passErr = document.getElementById('regPassErr');

  termsErr.textContent = '';
  passErr.textContent = '';

  if (name.value.trim().length < 3) isValid = false;
  if (!emailRegex.test(email.value.trim())) isValid = false;

  if (pass.value.length < 6) {
    pass.classList.add('error');
    passErr.textContent = 'La contraseña debe tener al menos 6 caracteres.';
    isValid = false;
  }

  if (pass.value !== passConfirm.value) {
    isValid = false;
  }

  // checkbox.checked es true/false según si está marcado o no
  if (!terms.checked) {
    termsErr.textContent = 'Debes aceptar los términos y condiciones.';
    isValid = false;
  }

  if (isValid) {
    this.style.display = 'none';
    const summary = document.getElementById('regSummary');
    // Template literal (comillas invertidas `` ` ``) permite insertar
    // variables directamente dentro del texto con ${...}
    document.getElementById('summaryText').textContent =
      `Bienvenido/a ${name.value}, tu cuenta con el correo ${email.value} ha sido creada correctamente.`;
    summary.style.display = 'block';
  }
});
