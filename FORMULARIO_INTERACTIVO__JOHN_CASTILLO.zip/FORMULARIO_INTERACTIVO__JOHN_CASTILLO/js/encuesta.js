// ============================================================================
// ENCUESTA.JS
// Lo importante aquí: la LÓGICA CONDICIONAL, un patrón muy común en
// formularios reales (ej: "¿Tienes alergias?" -> Sí -> aparece un campo
// para describirlas).
// ============================================================================

const reasonSelect = document.getElementById('reasonSelect');
const otherGroup = document.getElementById('otherGroup');

// El evento 'change' en un <select> se dispara cuando el usuario TERMINA
// de elegir una opción distinta (a diferencia de 'input', que en un
// select se comporta casi igual, pero 'change' es la convención estándar
// para elementos de selección).
reasonSelect.addEventListener('change', function () {
  // this.value es el valor de la opción actualmente seleccionada
  if (this.value === 'Otro') {
    otherGroup.style.display = 'block'; // revela el campo de texto extra
  } else {
    otherGroup.style.display = 'none';
    // Limpiamos el valor por si el usuario había escrito algo y luego
    // cambió de opinión: así no se envía un "motivo fantasma" oculto.
    document.getElementById('otherReason').value = '';
  }
});

// ============================================================================
// Envío del formulario: valida que todo esté completo y arma el resumen
// ============================================================================
document.getElementById('surveyForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const level = document.getElementById('academicLevel').value;
  const language = document.getElementById('language').value;
  const reason = reasonSelect.value;
  const otherReason = document.getElementById('otherReason').value.trim();

  // Validación simple: todos los campos deben tener valor, Y si el
  // motivo es "Otro", el campo de texto adicional TAMBIÉN debe tener algo.
  if (!level || !language || !reason || (reason === 'Otro' && !otherReason)) {
    alert('Por favor completa todos los campos de la encuesta.');
    return; // corta la función aquí, no sigue con el envío
  }

  // Si el motivo elegido fue "Otro", usamos el texto libre que escribió
  // el usuario; si no, usamos directamente el texto de la opción elegida.
  const motivoFinal = reason === 'Otro' ? otherReason : reason;

  const summaryList = document.getElementById('summaryList');
  // Insertamos varias líneas <li> de una sola vez usando un template
  // literal con las variables ya interpoladas dentro de ${...}
  summaryList.innerHTML = `
    <li><strong>Nivel Académico:</strong> ${level}</li>
    <li><strong>Lenguaje Preferido:</strong> ${language}</li>
    <li><strong>Motivo Especificado:</strong> ${motivoFinal}</li>
  `;

  this.style.display = 'none';                              // oculta el form
  document.getElementById('surveySummary').style.display = 'block'; // muestra el resumen
});
